const toggleBtn = document.querySelector('.inner-circle');
    const bodyBg = document.querySelector('body');
    const toggleButton = document.querySelector('.toggle-btn');
    const changeBg = document.querySelector('.toggle-btn');
    
    
    function toggleBt() {
      toggleBtn.addEventListener('click', () => {
        toggleBtn.classList.toggle('transform');
        changeBg.classList.toggle('change-bg');
        bodyBg.classList.toggle('body-bg');
        // Add fade class to bodyBg and toggleBtn
        bodyBg.classList.add('fade');
        toggleBtn.classList.add('fade');
    
        // Remove fade class after the animation duration (1s)
        setTimeout(() => {
          bodyBg.classList.remove('fade');
          toggleBtn.classList.remove('fade');
        }, 1000);
      });
    }
    
    toggleBt();