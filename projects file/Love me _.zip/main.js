const wrapper = document.querySelector('.content');
const circle = document.querySelector('.circle');
const question = document.getElementById('question');
const yesBtn = document.getElementById('yes');
const noBtn = document.getElementById('no');
const wrapperRect = wrapper.getBoundingClientRect();
const noRect = noBtn.getBoundingClientRect();


yesBtn.addEventListener('click', () => {
  question.innerHTML = "I Love You Too (:";
  circle.innerHTML = "😘";
  noBtn.style.right = '';
  noBtn.style.bottom = '';
  yesBtn.disabled = true;
  noBtn.disabled = true;
  refresh();
})

noBtn.addEventListener('click', () => {
  let i = Math.floor(Math.random(1, 40) * (wrapperRect.width - noRect.width)) + 1;
  let j = Math.floor(Math.random(1, 30) * (wrapperRect.height - noRect.height)) + 1;
  noBtn.style.right = i + "px";
  noBtn.style.bottom = j + "px";
})

function refresh() {
  let refresh = document.getElementById('refresh');
  refresh.style.display = 'block';
  refresh.addEventListener('click', () => {
    refresh.style.display = "none";
    yesBtn.disabled = false;
    noBtn.disabled = false;
    question.innerHTML = "Do you love me?";
    circle.innerHTML = "?";
  })
}