const hamburger = document.querySelector('.hamburger');
const dark = document.getElementById('dark');
const body = document.body; 

hamburger.addEventListener('click',() =>{
  hamburger.classList.toggle('active');
})

dark.addEventListener('click',() =>{
  body.classList.toggle('darkbg');
  hamburger.classList.toggle('darkbg');
  dark.classList.toggle('text');
})