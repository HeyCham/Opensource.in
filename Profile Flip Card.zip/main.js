const btn = document.querySelectorAll('.box');
const innerBox = document.querySelector('.inner-box-flip');

btn.forEach((btn) =>{
  btn.addEventListener('click',() =>{
  btn.classList.toggle('flip');
  btn.classList.toggle('inner-box-flip');
})
})

