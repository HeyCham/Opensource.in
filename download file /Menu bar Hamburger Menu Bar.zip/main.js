
document.querySelector('.menu-icon').addEventListener('click', function() {
    this.classList.toggle('menu-open')
})
