let toggle = document.querySelector('.toggle')
let menu = document.querySelector('.menu')

toggle.onclick = () => {
  menu.classList.toggle('active')
}